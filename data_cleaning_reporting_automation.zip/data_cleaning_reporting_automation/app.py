from pathlib import Path
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "raw_sales_data.csv"
st.set_page_config(page_title="Data Cleaning & Reporting", page_icon="🧹", layout="wide")
st.title("🧹 Data Cleaning & Reporting Automation")
st.caption("Clean a messy sample sales dataset and create summaries. Dataset is synthetic.")

raw = pd.read_csv(DATA)
st.subheader("Raw data preview")
c1, c2, c3 = st.columns(3)
c1.metric("Raw rows", f"{len(raw):,}")
c2.metric("Missing cells", f"{int(raw.isna().sum().sum()):,}")
c3.metric("Duplicate rows", f"{int(raw.duplicated().sum()):,}")
st.dataframe(raw.head(20), use_container_width=True)

df = raw.copy()
for col in ["Region", "Product", "CustomerID", "OrderID"]:
    df[col] = df[col].astype("string").str.strip()
df["Region"] = df["Region"].str.title()
df["Product"] = df["Product"].str.title()
df["OrderDate"] = pd.to_datetime(df["OrderDate"], errors="coerce")
for col in ["Quantity", "UnitPrice", "Sales"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")
df = df.drop_duplicates().dropna(subset=["OrderID", "OrderDate"])
df["Region"] = df["Region"].fillna("Unknown")
df["Product"] = df["Product"].fillna("Unknown")
df["CustomerID"] = df["CustomerID"].fillna("Unknown")
df["Quantity"] = df["Quantity"].fillna(df["Quantity"].median()).round().astype(int)
df["UnitPrice"] = df["UnitPrice"].fillna(df["UnitPrice"].median())
df["Sales"] = (df["Quantity"] * df["UnitPrice"]).round(2)
df = df.sort_values("OrderDate")

st.subheader("Cleaned data preview")
a, b, c = st.columns(3)
a.metric("Cleaned rows", f"{len(df):,}")
b.metric("Total sales", f"{df['Sales'].sum():,.0f}")
c.metric("Average order value", f"{df['Sales'].mean():,.0f}")
st.dataframe(df.head(30), use_container_width=True)

region = df.groupby("Region", as_index=False).agg(Orders=("OrderID", "count"), TotalSales=("Sales", "sum"))
monthly = df.assign(Month=df["OrderDate"].dt.to_period("M").astype(str)).groupby("Month", as_index=False)["Sales"].sum()
left, right = st.columns(2)
with left:
    st.subheader("Sales by region")
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(region["Region"], region["TotalSales"])
    ax.set_ylabel("Total sales"); fig.tight_layout()
    st.pyplot(fig); plt.close(fig)
with right:
    st.subheader("Monthly sales trend")
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(monthly["Month"], monthly["Sales"], marker="o")
    ax.tick_params(axis="x", rotation=60)
    ax.set_ylabel("Sales"); fig.tight_layout()
    st.pyplot(fig); plt.close(fig)

st.download_button("Download cleaned CSV", df.to_csv(index=False).encode("utf-8"),
                   "cleaned_sales_data.csv", "text/csv")
st.download_button("Download region summary CSV", region.to_csv(index=False).encode("utf-8"),
                   "region_sales_summary.csv", "text/csv")
