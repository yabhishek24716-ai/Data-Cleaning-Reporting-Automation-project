# Data Cleaning & Reporting Automation

A beginner-friendly Data Analytics project that automates cleaning, validation, reporting, and visualization of sales data using Python. It includes a deliberately messy sample dataset with missing values, duplicates, inconsistent category labels, and malformed fields.

## Features
- Clean column names and standardize text categories.
- Convert dates and numeric columns to appropriate data types.
- Remove duplicate orders and handle missing values.
- Validate sales totals and flag suspicious records.
- Export cleaned CSV and Excel reports.
- Generate a summary report and visual charts.
- Run an interactive Streamlit dashboard.

## Dataset
`data/raw_sales_data.csv` contains synthetic sales data for practice. It intentionally includes data quality issues to demonstrate the cleaning workflow. It is not real customer or business data.

## Setup
```bash
pip install -r requirements.txt
```

## Run automation
```bash
python src/clean_and_report.py
```

Generated files are saved to `outputs/`:
- `cleaned_sales_data.csv`
- `cleaning_summary.txt`
- `region_sales_summary.csv`
- `product_sales_summary.csv`
- `automated_sales_report.xlsx`
- `sales_by_region.png`
- `monthly_sales_trend.png`

## Run dashboard
```bash
streamlit run app.py
```

## Workflow
Raw data → inspect quality → standardize fields → parse and validate types → remove duplicates → impute missing values → calculate sales → summarize and visualize → export CSV/Excel reports.

## Notes
This is an educational project. Document assumptions when handling missing data; for real business data, do not overwrite the source and validate cleaning rules with the data owner.
