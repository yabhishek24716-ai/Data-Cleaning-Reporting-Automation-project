from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "raw_sales_data.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

def main():
    raw = pd.read_csv(DATA)
    original_rows = len(raw)
    missing_before = int(raw.isna().sum().sum())
    duplicate_rows = int(raw.duplicated().sum())

    df = raw.copy()
    df.columns = df.columns.str.strip().str.replace(" ", "", regex=False)
    # Normalize text fields
    for col in ["Region", "Product", "CustomerID", "OrderID"]:
        df[col] = df[col].astype("string").str.strip()
    df["Region"] = df["Region"].str.title()
    df["Product"] = df["Product"].str.title()

    # Parse types and identify malformed dates/numbers
    df["OrderDate"] = pd.to_datetime(df["OrderDate"], errors="coerce")
    for col in ["Quantity", "UnitPrice", "Sales"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Remove duplicate rows and rows without an order identifier
    df = df.drop_duplicates()
    df = df.dropna(subset=["OrderID"])
    rows_after_dedupe = len(df)

    # Remove records with invalid dates; fill missing values using explicit, simple rules
    df = df.dropna(subset=["OrderDate"])
    df["Region"] = df["Region"].fillna("Unknown")
    df["Product"] = df["Product"].fillna("Unknown")
    df["CustomerID"] = df["CustomerID"].fillna("Unknown")
    df["Quantity"] = df["Quantity"].fillna(df["Quantity"].median()).round().astype(int)
    df["UnitPrice"] = df["UnitPrice"].fillna(df["UnitPrice"].median())
    df.loc[df["Quantity"] < 0, "Quantity"] = df["Quantity"].median()
    df.loc[df["UnitPrice"] < 0, "UnitPrice"] = df["UnitPrice"].median()
    df["Sales"] = (df["Quantity"] * df["UnitPrice"]).round(2)

    # Data quality checks
    df["SalesCheck"] = (df["Sales"] >= 0)
    df = df.sort_values("OrderDate").reset_index(drop=True)

    region_summary = df.groupby("Region", dropna=False).agg(
        Orders=("OrderID", "count"),
        TotalSales=("Sales", "sum"),
        AverageOrderValue=("Sales", "mean")
    ).round(2).sort_values("TotalSales", ascending=False)
    product_summary = df.groupby("Product", dropna=False).agg(
        Orders=("OrderID", "count"),
        TotalSales=("Sales", "sum"),
        AverageOrderValue=("Sales", "mean")
    ).round(2).sort_values("TotalSales", ascending=False)
    monthly_summary = df.assign(Month=df["OrderDate"].dt.to_period("M").astype(str)).groupby("Month").agg(
        Orders=("OrderID", "count"), TotalSales=("Sales", "sum")
    ).reset_index()

    df.to_csv(OUT / "cleaned_sales_data.csv", index=False)
    region_summary.to_csv(OUT / "region_sales_summary.csv")
    product_summary.to_csv(OUT / "product_sales_summary.csv")
    monthly_summary.to_csv(OUT / "monthly_sales_summary.csv")

    # Excel workbook with multiple report sheets
    with pd.ExcelWriter(OUT / "automated_sales_report.xlsx", engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Cleaned Data", index=False)
        region_summary.to_excel(writer, sheet_name="Region Summary")
        product_summary.to_excel(writer, sheet_name="Product Summary")
        monthly_summary.to_excel(writer, sheet_name="Monthly Trend", index=False)

    plt.figure(figsize=(8, 4))
    region_summary["TotalSales"].sort_values().plot(kind="barh")
    plt.title("Total Sales by Region"); plt.xlabel("Sales"); plt.tight_layout()
    plt.savefig(OUT / "sales_by_region.png", dpi=160); plt.close()

    plt.figure(figsize=(9, 4))
    plt.plot(monthly_summary["Month"], monthly_summary["TotalSales"], marker="o")
    plt.title("Monthly Sales Trend"); plt.xlabel("Month"); plt.ylabel("Sales")
    plt.xticks(rotation=45, ha="right"); plt.tight_layout()
    plt.savefig(OUT / "monthly_sales_trend.png", dpi=160); plt.close()

    summary = (
        "DATA CLEANING & REPORTING SUMMARY\n"
        f"Original rows: {original_rows}\n"
        f"Missing cells before cleaning: {missing_before}\n"
        f"Duplicate rows detected: {duplicate_rows}\n"
        f"Rows after deduplication: {rows_after_dedupe}\n"
        f"Final cleaned rows: {len(df)}\n"
        f"Total sales: {df['Sales'].sum():,.2f}\n"
        f"Average order value: {df['Sales'].mean():,.2f}\n"
        f"Date range: {df['OrderDate'].min().date()} to {df['OrderDate'].max().date()}\n"
        "\nMissing-value handling: text fields -> 'Unknown'; Quantity and UnitPrice -> median; invalid dates -> row removed.\n"
    )
    (OUT / "cleaning_summary.txt").write_text(summary, encoding="utf-8")
    print(summary)
    print(f"Reports saved to: {OUT}")

if __name__ == "__main__":
    main()
