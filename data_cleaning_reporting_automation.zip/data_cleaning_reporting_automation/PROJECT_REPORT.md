# Data Cleaning & Reporting Automation — Project Report

## Abstract
This project automates a common data analytics workflow: inspect a raw dataset, clean missing and inconsistent values, remove duplicates, validate fields, create summary reports, and visualize key trends.

## Problem statement
Manual data cleaning and recurring reporting can be time-consuming and inconsistent. A repeatable script reduces repetitive work and produces standardized outputs.

## Objectives
1. Identify missing values, duplicate rows, and inconsistent labels.
2. Convert date and numeric fields to usable types.
3. Apply documented rules for invalid and missing values.
4. Generate regional, product, and monthly summaries.
5. Export cleaned data to CSV and Excel.
6. Visualize sales by region and monthly trend.

## Tools
Python, Pandas, NumPy, Matplotlib, Seaborn, OpenPyXL, Streamlit.

## Workflow
Load raw data → profile quality → normalize text → parse types → deduplicate → handle missing values → calculate sales → create summaries → export CSV/Excel → generate charts and dashboard.

## Data quality rules
- Normalize region and product labels.
- Parse invalid dates as missing and remove those rows.
- Remove exact duplicate rows.
- Fill missing text identifiers/categories with `Unknown`.
- Fill missing quantity and unit price with their medians.
- Recalculate sales as quantity multiplied by unit price.

These are demo rules. For a real dataset, missing-value treatment should be chosen with domain context and documented.

## Expected outcome
The project demonstrates repeatable preprocessing, reporting automation, and visual summaries that can be adapted to a business dataset.

## Limitations
The sample is synthetic. Median imputation is simple and may not be appropriate for every business context. This demo recalculates sales from quantity and unit price rather than trusting potentially inconsistent source totals.

## Conclusion
The project converts a deliberately messy CSV into cleaned data, multi-sheet Excel reports, summary CSVs, and charts. The Streamlit app makes the workflow easy to demonstrate in a portfolio.
